<?php
$host = "localhost"; // Nama hostnya
$user = "root"; // Username
$pass = ""; // Password (Isi jika menggunakan password)
$db = "db_mycake"; // Database (Isikan dengan nama database yang kamu buat)
$connect = mysqli_connect($host, $user, $pass, $db); // Koneksi ke MySQL

?> 